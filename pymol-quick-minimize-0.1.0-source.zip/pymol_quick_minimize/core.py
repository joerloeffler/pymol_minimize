"""OpenMM-backed restrained minimization of a PyMOL selection."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from io import StringIO
from copy import copy
import os
import math
from functools import wraps
from inspect import signature
from typing import Any


class MinimizationError(RuntimeError):
    """A user-facing error raised when a structure cannot be minimized safely."""


@dataclass(frozen=True)
class MinimizationResult:
    initial_energy_kj_mol: float
    final_energy_kj_mol: float
    atom_count: int
    movable_atom_count: int
    platform: str


# Residues covered by the Amber protein/nucleic-acid/water files. Variants are
# intentionally included here only for classifying disconnected small molecules;
# OpenMM remains the authority on whether a residue actually has a template.
_BIOPOLYMER_RESIDUES = {
    "ALA", "ARG", "ASH", "ASN", "ASP", "CYS", "CYM", "CYX", "GLH", "GLN",
    "GLU", "GLY", "HID", "HIE", "HIP", "HIS", "ILE", "LEU", "LYN", "LYS",
    "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL",
    "A", "C", "G", "U", "DA", "DC", "DG", "DT", "HOH", "WAT",
}

_SIMPLE_IONS = {
    "Li": 1, "Na": 1, "K": 1, "Rb": 1, "Cs": 1,
    "F": -1, "Cl": -1, "Br": -1, "I": -1,
    "Mg": 2, "Ca": 2, "Sr": 2, "Ba": 2, "Zn": 2,
}

_PROTEIN_BACKBONE_NAMES = {"N", "CA", "C", "O", "OXT"}


def _as_bool(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() not in {"0", "false", "no", "off", ""}
    return bool(value)


def _formal_charge(atom: Any) -> int:
    value = getattr(atom, "formal_charge", 0)
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _without_spurious_hydrogen_bonds(model):
    """Ignore extra inter-residue bonds on already bonded explicit hydrogens."""
    def residue(atom):
        return atom.model, atom.segi, atom.chain, atom.resi, atom.resn

    internally_bonded_h = set()
    for bond in model.bond:
        i, j = bond.index
        if residue(model.atom[i]) == residue(model.atom[j]):
            for index in (i, j):
                if (model.atom[index].symbol or model.atom[index].elem).upper() == "H":
                    internally_bonded_h.add(index)
    cleaned = copy(model)
    cleaned.bond = [
        bond for bond in model.bond
        if not (
            residue(model.atom[bond.index[0]]) != residue(model.atom[bond.index[1]])
            and internally_bonded_h.intersection(bond.index)
        )
    ]
    return cleaned


def _build_topology(model: Any):
    from openmm.app import Element, Topology

    topology = Topology()
    chains = {}
    residues = {}
    omm_atoms = [None] * len(model.atom)
    # OpenMM requires atom indices to follow chain/residue traversal order.
    # PyMOL can interleave waters with protein residues sharing the same resi.
    groups = {}
    for position, atom in enumerate(model.atom):
        key = (atom.model or "", atom.segi or "", atom.chain or "")
        groups.setdefault(key, {}).setdefault((atom.resi, atom.resn), []).append(position)
    ordered = []
    for chain_residues in groups.values():
        residue_groups = sorted(
            chain_residues.items(),
            key=lambda item: item[0][1].upper() not in (_BIOPOLYMER_RESIDUES - {"HOH", "WAT"}),
        )
        for _, indices in residue_groups:
            ordered.extend(indices)

    atom_names = {}
    for chain_residues in groups.values():
        for (_, resn), indices in chain_residues.items():
            names = [model.atom[i].name for i in indices]
            if len(set(names)) != len(names) and resn.upper() not in _BIOPOLYMER_RESIDUES:
                # PDB ligands often use only element names. Assign unique names
                # in the working topology; PyMOL names and atom order stay intact.
                for number, i in enumerate(indices, 1):
                    atom_names[i] = f"X{number}"

    for position in ordered:
        atom = model.atom[position]
        chain_key = (atom.model or "", atom.segi or "", atom.chain or "")
        chain = chains.get(chain_key)
        if chain is None:
            chain = topology.addChain(atom.chain or None)
            chains[chain_key] = chain

        residue_key = (chain_key, atom.resi, atom.resn)
        residue = residues.get(residue_key)
        if residue is None:
            residue = topology.addResidue(atom.resn or "UNK", chain, id=atom.resi or None)
            residues[residue_key] = residue

        symbol = (atom.symbol or atom.elem or "").strip().capitalize()
        try:
            element = Element.getBySymbol(symbol)
        except Exception as exc:
            raise MinimizationError(
                f"Atom {atom.name!r} in {atom.resn}{atom.resi} has unsupported element {symbol!r}."
            ) from exc
        # Numeric, globally unique ids survive OpenMM Modeller's topology copy.
        name = atom_names.get(position, atom.name or symbol)
        if atom.resn.upper() in {"A", "C", "G", "U", "DA", "DC", "DG", "DT"}:
            name = {"O1P": "OP1", "O2P": "OP2", "O3P": "OP3"}.get(name, name)
            name = name.replace("*", "'")
        omm_atoms[position] = topology.addAtom(name, element, residue, id=str(position + 1))

    bond_types = {1: None, 2: "Double", 3: "Triple", 4: "Aromatic"}
    from openmm.app import Double, Triple, Aromatic
    type_objects = {"Double": Double, "Triple": Triple, "Aromatic": Aromatic}
    for bond in model.bond:
        order = int(round(getattr(bond, "order", 1) or 1))
        topology.addBond(
            omm_atoms[bond.index[0]],
            omm_atoms[bond.index[1]],
            type=type_objects.get(bond_types.get(order)),
            order=1.5 if order == 4 else order,
        )

    return topology


def _small_molecules_from_model(model: Any):
    """Convert disconnected non-biopolymer components into OpenFF molecules."""
    from openff.toolkit import Molecule
    from rdkit import Chem
    from rdkit.Geometry import Point3D

    adjacency = [set() for _ in model.atom]
    for bond in model.bond:
        i, j = bond.index
        adjacency[i].add(j)
        adjacency[j].add(i)

    unseen = set(range(len(model.atom)))
    components = []
    while unseen:
        root = unseen.pop()
        component = {root}
        stack = [root]
        while stack:
            for neighbor in adjacency[stack.pop()]:
                if neighbor in unseen:
                    unseen.remove(neighbor)
                    component.add(neighbor)
                    stack.append(neighbor)
        components.append(sorted(component))

    molecules = []
    for component in components:
        residue_names = {model.atom[i].resn.upper() for i in component}
        if residue_names <= _BIOPOLYMER_RESIDUES:
            continue
        if residue_names & _BIOPOLYMER_RESIDUES:
            # A covalently attached ligand/PTM cannot safely be treated as a
            # disconnected OpenFF molecule. OpenMM will report the missing template.
            continue

        if len(component) == 1:
            source = model.atom[component[0]]
            symbol = (source.symbol or source.elem).strip().capitalize()
            if symbol in _SIMPLE_IONS:
                charge = _formal_charge(source)
                if charge not in (0, _SIMPLE_IONS[symbol]):
                    raise MinimizationError(
                        f"Unsupported charge {charge} for isolated {symbol}; "
                        f"the Amber ion template uses {_SIMPLE_IONS[symbol]:+d}."
                    )
                continue

        rw = Chem.RWMol()
        old_to_new = {}
        for old_index in component:
            source = model.atom[old_index]
            atom = Chem.Atom((source.symbol or source.elem).strip().capitalize())
            atom.SetFormalCharge(_formal_charge(source))
            atom.SetNoImplicit(True)
            atom.SetProp("_Name", source.name)
            old_to_new[old_index] = rw.AddAtom(atom)

        for bond in model.bond:
            i, j = bond.index
            if i not in old_to_new or j not in old_to_new:
                continue
            order = int(round(getattr(bond, "order", 1) or 1))
            bond_type = {
                1: Chem.BondType.SINGLE,
                2: Chem.BondType.DOUBLE,
                3: Chem.BondType.TRIPLE,
                4: Chem.BondType.AROMATIC,
            }.get(order, Chem.BondType.SINGLE)
            rw.AddBond(old_to_new[i], old_to_new[j], bond_type)

        mol = rw.GetMol()
        conformer = Chem.Conformer(len(component))
        for old_index, new_index in old_to_new.items():
            x, y, z = model.atom[old_index].coord
            conformer.SetAtomPosition(new_index, Point3D(float(x), float(y), float(z)))
        mol.AddConformer(conformer)
        # PyMOL's order 4 also marks non-ring resonance bonds. Resolve
        # recognizable carboxylates and guanidinium locally, preserving all
        # other supplied bond orders rather than searching the entire ligand.
        Chem.GetSymmSSSR(mol)
        for center in mol.GetAtoms():
            if center.GetSymbol() != "C" or center.GetDegree() != 3:
                continue
            neighbors = list(center.GetNeighbors())
            resonance = [
                bond for bond in center.GetBonds()
                if bond.GetBondType() == Chem.BondType.AROMATIC and not bond.IsInRing()
            ]
            if not resonance:
                continue
            oxygens = [atom for atom in neighbors if atom.GetSymbol() == "O"]
            nitrogens = [atom for atom in neighbors if atom.GetSymbol() == "N"]
            if len(oxygens) == 2 and len(resonance) == 2:
                terminal = [atom for atom in oxygens if atom.GetDegree() == 1]
                if not terminal:
                    continue
                double_atom = terminal[0]
                for atom in oxygens:
                    bond = mol.GetBondBetweenAtoms(center.GetIdx(), atom.GetIdx())
                    bond.SetBondType(Chem.BondType.DOUBLE if atom.GetIdx() == double_atom.GetIdx() else Chem.BondType.SINGLE)
                    atom.SetFormalCharge(-1 if atom.GetIdx() != double_atom.GetIdx() and atom.GetDegree() == 1 else 0)
            elif len(nitrogens) == 3:
                double_atom = resonance[0].GetOtherAtom(center)
                for atom in nitrogens:
                    bond = mol.GetBondBetweenAtoms(center.GetIdx(), atom.GetIdx())
                    bond.SetBondType(Chem.BondType.DOUBLE if atom.GetIdx() == double_atom.GetIdx() else Chem.BondType.SINGLE)
                    atom.SetFormalCharge(1 if atom.GetIdx() == double_atom.GetIdx() and atom.GetDegree() == 3 else 0)
        for bond in mol.GetBonds():
            bond.SetIsAromatic(bond.GetBondType() == Chem.BondType.AROMATIC)
        for atom in mol.GetAtoms():
            atom.SetIsAromatic(any(bond.GetIsAromatic() for bond in atom.GetBonds()))
        try:
            if any(
                mol.GetBondBetweenAtoms(old_to_new[bond.index[0]], old_to_new[bond.index[1]]).GetBondType()
                == Chem.BondType.AROMATIC
                and (len(adjacency[bond.index[0]]) == 1 or len(adjacency[bond.index[1]]) == 1)
                for bond in model.bond
                if bond.index[0] in old_to_new and bond.index[1] in old_to_new
            ):
                raise ValueError("terminal delocalized bond requires bond-order inference")
            Chem.SanitizeMol(mol)
            if any(atom.GetNumRadicalElectrons() for atom in mol.GetAtoms()):
                raise ValueError("PDB bond orders produced radicals; infer closed-shell valence")
        except Exception:
            # PyMOL uses bond order 4 both for aromatic bonds and for some
            # delocalized/resonance bonds (notably terminal carboxylates). Rebuild
            # connectivity and let RDKit infer bond orders from valence and 3D
            # coordinates when the literal aromatic interpretation is invalid.
            from rdkit.Chem import rdDetermineBonds

            fallback = Chem.RWMol()
            fallback_old_to_new = {}
            for old_index in component:
                source = model.atom[old_index]
                atom = Chem.Atom((source.symbol or source.elem).strip().capitalize())
                atom.SetFormalCharge(_formal_charge(source))
                atom.SetNoImplicit(True)
                atom.SetProp("_Name", source.name)
                fallback_old_to_new[old_index] = fallback.AddAtom(atom)
            for bond in model.bond:
                i, j = bond.index
                if i in fallback_old_to_new and j in fallback_old_to_new:
                    fallback.AddBond(
                        fallback_old_to_new[i], fallback_old_to_new[j], Chem.BondType.SINGLE
                    )
            fallback_mol = fallback.GetMol()
            fallback_conformer = Chem.Conformer(len(component))
            for old_index, new_index in fallback_old_to_new.items():
                x, y, z = model.atom[old_index].coord
                fallback_conformer.SetAtomPosition(
                    new_index, Point3D(float(x), float(y), float(z))
                )
            fallback_mol.AddConformer(fallback_conformer)
            try:
                stated_charge = sum(_formal_charge(model.atom[i]) for i in component)
                charge_candidates = [stated_charge]
                if stated_charge == 0:
                    # PDB/mmCIF exports frequently omit ligand formal charges.
                    # Try common small net charges, preferring anions before
                    # cations because deprotonated oxygens are common.
                    charge_candidates.extend([-1, 1, -2, 2, -3, 3, -4, 4, -5, 5, -6, 6])
                last_error = None
                for total_charge in charge_candidates:
                    candidate = Chem.Mol(fallback_mol)
                    try:
                        rdDetermineBonds.DetermineBondOrders(
                            candidate, charge=total_charge, allowChargedFragments=True,
                            maxIterations=1000
                        )
                        Chem.SanitizeMol(candidate)
                        fallback_mol = candidate
                        break
                    except Exception as charge_error:
                        last_error = charge_error
                else:
                    raise last_error
                mol = fallback_mol
            except Exception as exc:
                names = ", ".join(sorted(residue_names))
                raise MinimizationError(
                    f"Could not determine chemically valid bond orders/charges for {names}. "
                    "Load that ligand from SDF or MOL2 (not PDB), then try again."
                ) from exc
        try:
            molecules.append(
                Molecule.from_rdkit(mol, allow_undefined_stereo=True, hydrogens_are_explicit=True)
            )
        except Exception as exc:
            names = ", ".join(sorted(residue_names))
            raise MinimizationError(
                f"Could not determine chemically valid bond orders/charges for {names}. "
                "Load that ligand from SDF or MOL2 (not PDB), then try again."
            ) from exc

    return molecules


def _energy(context) -> float:
    from openmm import unit

    state = context.getState(getEnergy=True)
    return float(state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole))


def _repair_missing_heavy_atoms(topology, positions):
    """Use PDBFixer to add missing atoms without guessing missing residues."""
    from openmm.app import PDBFile
    from pdbfixer import PDBFixer

    # PDBFixer treats names such as UNK as standard residues with no known
    # bonds. Its atom-insertion path can therefore discard explicit ligand
    # connectivity. Record it by identities stable across topology copies.
    ligand_bonds = []
    for bond in topology.bonds():
        left, right = bond
        if (left.residue.name.upper() not in _BIOPOLYMER_RESIDUES
                or right.residue.name.upper() not in _BIOPOLYMER_RESIDUES):
            ligand_bonds.append(
                (_topology_atom_key(left), _topology_atom_key(right), bond.type, bond.order)
            )
    buffer = StringIO()
    # Temporary sequential residue IDs avoid protein/water numbering collisions.
    PDBFile.writeFile(topology, positions, buffer, keepIds=False)
    buffer.seek(0)
    fixer = PDBFixer(pdbfile=buffer)
    fixer.findMissingResidues()
    fixer.missingResidues = {}
    fixer.findMissingAtoms()
    if fixer.missingAtoms or fixer.missingTerminals:
        fixer.addMissingAtoms()
    repaired_atoms = {_topology_atom_key(atom): atom for atom in fixer.topology.atoms()}
    existing_bonds = {
        frozenset((_topology_atom_key(left), _topology_atom_key(right)))
        for left, right in fixer.topology.bonds()
    }
    for left_key, right_key, bond_type, order in ligand_bonds:
        if left_key not in repaired_atoms or right_key not in repaired_atoms:
            raise MinimizationError("Heavy-atom repair changed an original ligand atom identity.")
        key = frozenset((left_key, right_key))
        if key not in existing_bonds:
            fixer.topology.addBond(
                repaired_atoms[left_key], repaired_atoms[right_key], type=bond_type, order=order
            )
            existing_bonds.add(key)
    return fixer.topology, fixer.positions


def _template_cache_path(cache: str):
    if cache and cache != "auto":
        path = Path(cache).expanduser()
    elif cache == "auto":
        if os.name == "nt" and os.environ.get("LOCALAPPDATA"):
            root = Path(os.environ["LOCALAPPDATA"])
        elif os.environ.get("XDG_CACHE_HOME"):
            root = Path(os.environ["XDG_CACHE_HOME"])
        else:
            root = Path.home() / ".cache"
        path = root / "pymol-quick-minimize" / "openff-templates.json"
    else:
        return None
    path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)


def _topology_atom_key(atom) -> tuple[int, int, str]:
    """Identity stable across OpenMM Modeller topology reconstruction."""
    return atom.residue.chain.index, atom.residue.index, atom.name


def _iteration_stages(limit, thorough):
    """Share a total iteration budget across the staged protocol."""
    limit = int(limit)
    if limit < 1:
        raise MinimizationError("max_iterations must be positive.")
    if not thorough:
        return (0, 0, limit)
    first = min(300, limit // 6)
    second = min(500, limit * 5 // 18)
    return first, second, limit - first - second


def _restore_on_failure(function):
    parameters = signature(function)
    @wraps(function)
    def wrapped(*args, **kwargs):
        from pymol import cmd as pymol_cmd
        cmd = parameters.bind_partial(*args, **kwargs).arguments.get("_cmd") or pymol_cmd
        snapshot = cmd.get_session()
        try:
            return function(*args, **kwargs)
        except Exception:
            cmd.set_session(snapshot)
            raise
    return wrapped


@_restore_on_failure
def minimize_selection(
    selection: str = "sele",
    system: str = "all",
    state: int = 1,
    max_iterations: int = 500,
    tolerance: float = 10.0,
    restraint: float = 1000.0,
    add_hydrogens: Any = 1,
    forcefield: str = "openff-2.2.1",
    cache: str = "auto",
    implicit_solvent: Any = 1,
    relax_mode: str = "quick",
    quiet: Any = 0,
    _cmd=None,
) -> MinimizationResult:
    """Minimize ``selection`` while restraining the rest of ``system``.

    This function is also registered as the PyMOL command ``quick_minimize``.
    Energies are in kJ/mol, tolerance in kJ/mol/nm, and restraint strength in
    kJ/mol/nm^2.
    """
    from pymol import cmd as pymol_cmd
    from openmm import CustomExternalForce, LangevinMiddleIntegrator, Platform, Vec3, unit
    from openmm.app import Modeller, NoCutoff, Simulation
    from openmmforcefields.generators import SystemGenerator

    cmd = _cmd or pymol_cmd
    state = int(state)
    max_iterations = int(max_iterations)
    tolerance = float(tolerance)
    restraint = float(restraint)
    _iteration_stages(max_iterations, False)
    if not math.isfinite(tolerance) or tolerance <= 0:
        raise MinimizationError("tolerance must be finite and positive.")
    if not math.isfinite(restraint) or restraint < 0:
        raise MinimizationError("restraint must be finite and nonnegative.")
    quiet = _as_bool(quiet)
    implicit_solvent = _as_bool(implicit_solvent)
    relax_mode = str(relax_mode).strip().lower()
    if relax_mode not in {"quick", "thorough"}:
        raise MinimizationError("relax_mode must be 'quick' or 'thorough'.")

    if cmd.count_atoms(selection) == 0:
        raise MinimizationError(f"Selection {selection!r} contains no atoms.")
    if cmd.count_atoms(system) == 0:
        raise MinimizationError(f"System selection {system!r} contains no atoms.")

    input_model = cmd.get_model(system, state)
    cleaned_model = _without_spurious_hydrogen_bonds(input_model)
    retained_bonds = {tuple(bond.index) for bond in cleaned_model.bond}
    for bond in input_model.bond:
        if tuple(bond.index) not in retained_bonds:
            left, right = (input_model.atom[i] for i in bond.index)
            cmd.unbond(
                f"model {left.model} and index {left.index}",
                f"model {right.model} and index {right.index}",
            )

    if _as_bool(add_hydrogens):
        # PyMOL generally does a useful job on standalone organic molecules, and
        # those explicit H atoms are required to preserve the ligand's identity.
        # Protein H atoms are added below by OpenMM, whose residue templates know
        # the correct terminal/protonation naming and bonding patterns.
        standard_names = "+".join(sorted(_BIOPOLYMER_RESIDUES))
        cmd.h_add(f"({system}) and not polymer and not resn {standard_names}", state=state)

    model = _without_spurious_hydrogen_bonds(cmd.get_model(system, state))
    if not model.atom:
        raise MinimizationError("No atoms were available after structure preparation.")

    system_indices = [(atom.model, atom.index) for atom in model.atom]
    movable_indices = set(cmd.index(f"({system}) and ({selection})"))
    movable_positions = {i for i, identity in enumerate(system_indices) if identity in movable_indices}
    if not movable_positions:
        raise MinimizationError("The movable selection does not overlap the system selection.")

    topology = _build_topology(model)
    positions = [
        Vec3(*map(float, model.atom[int(atom.id) - 1].coord))
        for atom in topology.atoms()
    ] * unit.angstrom
    original_atom_keys = [None] * len(model.atom)
    for atom in topology.atoms():
        original_atom_keys[int(atom.id) - 1] = _topology_atom_key(atom)
    if len(set(original_atom_keys)) != len(original_atom_keys):
        raise MinimizationError(
            "The system contains duplicate atom names within a residue. Rename atoms uniquely "
            "before minimization so coordinates can be mapped back safely."
        )
    movable_original_keys = {
        original_atom_keys[i] for i in movable_positions
    }
    movable_residue_keys = {
        key[:2] for key in movable_original_keys
    }
    molecules = _small_molecules_from_model(model)
    try:
        topology, positions = _repair_missing_heavy_atoms(topology, positions)
    except Exception as exc:
        raise MinimizationError("Automatic heavy-atom/terminal repair failed: " + str(exc)) from exc

    cache_path = _template_cache_path(cache)
    forcefield_files = ["amber/protein.ff14SB.xml", "amber/DNA.OL15.xml",
                        "amber/RNA.OL3.xml", "amber/tip3p_standard.xml"]
    if implicit_solvent:
        forcefield_files.append("implicit/obc2.xml")
    generator = SystemGenerator(
        forcefields=forcefield_files,
        small_molecule_forcefield=forcefield,
        forcefield_kwargs={"constraints": None, "rigidWater": False, "removeCMMotion": False},
        nonperiodic_forcefield_kwargs={"nonbondedMethod": NoCutoff},
        molecules=molecules,
        cache=cache_path,
    )
    if _as_bool(add_hydrogens):
        modeller = Modeller(topology, positions)
        try:
            modeller.addHydrogens(generator.forcefield)
        except Exception as exc:
            raise MinimizationError(
                "Hydrogen placement failed. Check residue names, missing heavy atoms, and ligand "
                "bond orders. Original error: " + str(exc)
            ) from exc
        topology, positions = modeller.topology, modeller.positions

    # Modeller inserts and renumbers protein hydrogens. Chain/residue indices and
    # unique atom names are stable; generated H atoms inherit mobility by residue.
    position_by_key = {
        _topology_atom_key(atom): i for i, atom in enumerate(topology.atoms())
    }
    missing_keys = [key for key in original_atom_keys if key not in position_by_key]
    if missing_keys:
        raise MinimizationError(
            "OpenMM structure preparation changed original atom identities; refusing unsafe "
            "coordinate write-back."
        )
    original_key_set = set(original_atom_keys)
    movable_positions = {
        i for i, atom in enumerate(topology.atoms())
        if _topology_atom_key(atom) in movable_original_keys
        or (_topology_atom_key(atom) not in original_key_set
            and _topology_atom_key(atom)[:2] in movable_residue_keys)
    }
    try:
        omm_system = generator.create_system(topology, molecules=molecules)
    except Exception as exc:
        raise MinimizationError(
            "Force-field assignment failed. Check protonation, explicit hydrogens, bond orders, "
            "metals, and covalently attached non-standard residues. Original error: " + str(exc)
        ) from exc

    if restraint > 0:
        restraint_force = CustomExternalForce("k*((x-x0)^2+(y-y0)^2+(z-z0)^2)")
        restraint_force.addGlobalParameter("k", restraint * unit.kilojoule_per_mole / unit.nanometer**2)
        for parameter in ("x0", "y0", "z0"):
            restraint_force.addPerParticleParameter(parameter)
        positions_nm = positions.value_in_unit(unit.nanometer)
        for i, xyz in enumerate(positions_nm):
            if i not in movable_positions:
                restraint_force.addParticle(i, [float(xyz[0]), float(xyz[1]), float(xyz[2])])
        omm_system.addForce(restraint_force)

    movable_tether = None
    if relax_mode == "thorough":
        movable_tether = CustomExternalForce(
            "movable_k*((x-x0)^2+(y-y0)^2+(z-z0)^2)"
        )
        movable_tether.addGlobalParameter(
            "movable_k", 5000 * unit.kilojoule_per_mole / unit.nanometer**2
        )
        for parameter in ("x0", "y0", "z0"):
            movable_tether.addPerParticleParameter(parameter)
        positions_nm = positions.value_in_unit(unit.nanometer)
        topology_atoms = list(topology.atoms())
        for i in movable_positions:
            if topology_atoms[i].element.symbol != "H":
                xyz = positions_nm[i]
                movable_tether.addParticle(i, [float(xyz[0]), float(xyz[1]), float(xyz[2])])
        omm_system.addForce(movable_tether)

    # Keep the experimental/model backbone close to its input even when a
    # residue-wise pocket selection includes backbone atoms (or selection=all).
    backbone_tether = CustomExternalForce(
        "backbone_k*((x-x0)^2+(y-y0)^2+(z-z0)^2)"
    )
    backbone_tether.addGlobalParameter(
        "backbone_k", 500 * unit.kilojoule_per_mole / unit.nanometer**2
    )
    for parameter in ("x0", "y0", "z0"):
        backbone_tether.addPerParticleParameter(parameter)
    positions_nm = positions.value_in_unit(unit.nanometer)
    for atom in topology.atoms():
        if atom.residue.name.upper() in _BIOPOLYMER_RESIDUES and atom.name in _PROTEIN_BACKBONE_NAMES:
            xyz = positions_nm[atom.index]
            backbone_tether.addParticle(
                atom.index, [float(xyz[0]), float(xyz[1]), float(xyz[2])]
            )
    omm_system.addForce(backbone_tether)

    integrator = LangevinMiddleIntegrator(300 * unit.kelvin, 1 / unit.picosecond, 0.002 * unit.picoseconds)
    platform = Platform.getPlatformByName("CPU")
    simulation = Simulation(topology, omm_system, integrator, platform)
    simulation.context.setPositions(positions)
    initial_energy = _energy(simulation.context)
    stages = _iteration_stages(max_iterations, relax_mode == "thorough")
    if relax_mode == "thorough":
        if stages[0]:
            simulation.minimizeEnergy(tolerance=50, maxIterations=stages[0])
        simulation.context.setParameter("movable_k", 100.0)
        if stages[1]:
            simulation.minimizeEnergy(tolerance=20, maxIterations=stages[1])
        simulation.context.setParameter("movable_k", 0.0)
        simulation.minimizeEnergy(tolerance=tolerance, maxIterations=stages[2])
    else:
        simulation.minimizeEnergy(tolerance=tolerance, maxIterations=max_iterations)
    final_energy = _energy(simulation.context)
    minimized = simulation.context.getState(getPositions=True).getPositions(asNumpy=True)
    coordinates = minimized.value_in_unit(unit.angstrom)
    import numpy as np
    if not np.isfinite(coordinates).all() or not math.isfinite(final_energy):
        raise MinimizationError("Minimization produced non-finite coordinates or energy.")
    original_coordinates = [
        coordinates[position_by_key[key]] for key in original_atom_keys
    ]
    cmd.load_coords(original_coordinates, system, state=state)
    cmd.rebuild()

    result = MinimizationResult(
        initial_energy_kj_mol=initial_energy,
        final_energy_kj_mol=final_energy,
        atom_count=omm_system.getNumParticles(),
        movable_atom_count=len(movable_positions),
        platform=platform.getName(),
    )
    if not quiet:
        print(
            f"{relax_mode.title()} Relax: "
            f"{result.movable_atom_count}/{result.atom_count} atoms movable; "
            + ("OBC2 implicit solvent" if implicit_solvent else "fast nonperiodic field")
            + f" ({result.platform})"
        )
    return result


def quick_relax(selection="sele", system="all", quiet=0, _cmd=None, **kwargs):
    """Fast selected-atom relaxation in the field of the complete system."""
    from pymol import cmd as pymol_cmd
    from .amber_backend import relax_compiled, requires_compiled_backend

    # PyMOL's cmd.extend may inject its command instance as ``_self``. It is
    # control metadata, not a minimization option, so consume it at this public
    # wrapper boundary before dispatching to either chemistry backend.
    pymol_self = kwargs.pop("_self", None)
    active_cmd = _cmd or pymol_self or pymol_cmd
    # MOE-like behavior: with no active PyMOL selection, relax the complete
    # system instead of failing on the conventional but absent ``sele`` name.
    if str(selection).strip() == "sele" and "sele" not in active_cmd.get_names("selections"):
        selection = system
    if requires_compiled_backend(active_cmd, system, int(kwargs.get("state", 1))):
        _check_compiled_options(kwargs)
        return relax_compiled(
            selection, system, mode="quick", quiet=quiet, _cmd=active_cmd,
            state=kwargs.get("state", 1), max_iterations=kwargs.get("max_iterations"),
            restraint=kwargs.get("restraint", 1000.0),
            tolerance=kwargs.get("tolerance", 25.0),
            implicit_solvent=kwargs.get("implicit_solvent", False),
            add_hydrogens=kwargs.get("add_hydrogens", True),
        )
    kwargs.setdefault("max_iterations", 100)
    kwargs.setdefault("tolerance", 25.0)
    kwargs.setdefault("restraint", 1000.0)
    kwargs.setdefault("implicit_solvent", 0)
    kwargs["relax_mode"] = "quick"
    return minimize_selection(selection, system, quiet=quiet, _cmd=active_cmd, **kwargs)


def thorough_relax(selection="sele", system="all", quiet=0, _cmd=None, **kwargs):
    """Staged implicit-solvent relaxation for difficult clashes."""
    from pymol import cmd as pymol_cmd
    from .amber_backend import relax_compiled, requires_compiled_backend

    pymol_self = kwargs.pop("_self", None)
    active_cmd = _cmd or pymol_self or pymol_cmd
    if str(selection).strip() == "sele" and "sele" not in active_cmd.get_names("selections"):
        selection = system
    if requires_compiled_backend(active_cmd, system, int(kwargs.get("state", 1))):
        _check_compiled_options(kwargs)
        return relax_compiled(
            selection, system, mode="thorough", quiet=quiet, _cmd=active_cmd,
            state=kwargs.get("state", 1), max_iterations=kwargs.get("max_iterations"),
            restraint=kwargs.get("restraint", 1000.0),
            tolerance=kwargs.get("tolerance", 10.0),
            implicit_solvent=kwargs.get("implicit_solvent", True),
            add_hydrogens=kwargs.get("add_hydrogens", True),
        )
    kwargs.setdefault("max_iterations", 1000)
    kwargs.setdefault("tolerance", 10.0)
    kwargs.setdefault("restraint", 1000.0)
    kwargs.setdefault("implicit_solvent", 1)
    kwargs["relax_mode"] = "thorough"
    return minimize_selection(selection, system, quiet=quiet, _cmd=active_cmd, **kwargs)


def _check_compiled_options(options):
    supported = {"state", "max_iterations", "restraint", "tolerance",
                 "implicit_solvent", "add_hydrogens"}
    unsupported = set(options) - supported
    if unsupported:
        raise MinimizationError(
            "Unsupported options for the Amber/GLYCAM backend: "
            + ", ".join(sorted(unsupported))
        )
